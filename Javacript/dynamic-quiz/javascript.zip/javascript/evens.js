let foo = [1, 2, 3, 4, 5];
let bar = foo.filter(num => num % 2 === 0);
console.log(bar);
