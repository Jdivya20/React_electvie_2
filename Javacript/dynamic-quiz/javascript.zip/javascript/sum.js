let foo = [1, 2, 3, 4, 5];
let sum = foo.reduce((acc, num) => acc + num);
console.log(sum);
