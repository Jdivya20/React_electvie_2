let foo = [1, 2, 3, 4, 5];
let bar = foo.map(x => x * 2);
console.log(bar);
